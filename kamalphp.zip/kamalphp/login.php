
<?php
session_start();
$host="localhost";
$uname="root";
$pwd="";
$dbname="dblogin";
$conn=mysqli_connect($host,$uname,$pwd,"$dbname");
if(!$conn)
{
	die("connection failed" .mysqli_connect_error());
}
if(isset($_POST["login"]))
{
	$un=$_POST['txtusr'];
	$pwd=$_POST['txtpwd'];
	if($un!=''&&$pwd!='')
 {
   $query="select * from tbusr where username='".$un."' and upawd='".$pwd."' "  or die(mysqli_error());
   $res=mysqli_query($conn,$query);
   $r1=mysqli_fetch_row($res);
   if($r1)
   {
    $_SESSION['name']=$r1[3]." ".$r1[4];
    $_SESSION["ucod"]=$r1[0];
    header('location:profile.php');
   }
   else
   {
    echo'You entered username or password is incorrect';
   }
 }
 else
 {
  echo'Enter both username and password';
 }
}
?>
<html>
<head>
</head>
<body>
<form name="formlog" action="login.php" method="post" enctype="multipart/form-data">
<table border="5">
<tr>
	<td>User name:</td>
	<td><input type="text" name="txtusr" /></td>
</tr>
<tr>
	<td>Password:</td>
	<td><input type="password" name="txtpwd" /></td>
</tr>
<tr>
	<td colspan="2">
		<input type="submit" name="login" value="Login">
	</td>
	</tr>
	<tr><td></td><td> <span><a href="forgot.php">Forgot password</a></span>
</table>
</form>
</body>
</html>


