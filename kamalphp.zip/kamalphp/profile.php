
<?php
session_start();
$host="localhost";
$uname="root";
$pwd="";
$dbname="dblogin";
$conn=mysqli_connect("$host","$uname","$pwd","$dbname");
if(!$conn)
{
  die("connection failed" .mysqli_connect_error());
}
if(isset($_POST["btn"]))
{
  $upload="/opt/lampp/htdocs/uploadimage/";


  //echo $upload;die;
  $ucod=$_SESSION['ucod'];
   $ucod;
   $pic=$_FILES["txtpic"]["name"];
 // die();


  $uploadsucess = move_uploaded_file($_FILES["txtpic"]["tmp_name"], $upload . $_FILES['txtpic']['name']);


if($uploadsucess)
{

  echo "image uploaded successfully";

  $qry2="INSERT INTO tbimages (image ,usrid) VALUES ($pic ,$ucod)";
  $res2=mysqli_query($conn,$qry2);

}
else{


        echo "image not uploaded successfully";



}
}
?>
<html>
<head>
</head>
<body>
  <form name="f1" action="profile.php" method="post" enctype="multipart/form-data">
<table>
  <tr>
    <?php
   echo 'welcome'.' '. $_SESSION["name"];
   echo "<a href=home.php>Home</a>";

   // echo $_SESSION["name"];die("new session");
    $qry1="select * from tbusr where ucod=".$_SESSION['ucod'];
    $res1=mysqli_query($conn,$qry1);
    //print_r($res1) ; die('hello');
    echo "<table>";
    if($r1=mysqli_fetch_row($res1))
    {
      if($r1[0]==$_SESSION["ucod"])
      {
      echo"<tr>";
      echo"<td><img src=uploadimage/$r1[7] height=50 width=35></td>";
       echo"<td>Username :$r1[1]<br>";
        echo "First Name:$r1[3]<br>";
        echo "Last Name:$r1[4]<br>";
        echo "Address :$r1[5]<br>";
        echo "Contact :$r1[6]<br>";
        echo "Gender :$r1[8]</td>";
      }
    }
    echo "</table>";
    ?>

</tr>
<tr>
  <td><a href=Detail.php>See All Frisnds</a><br><br></td>
</tr>
<tr>
  <td>
    <input type="file" name="txtpic">
    <input type="submit" name="btn" value="Add Photo">
</td>
</tr>
</table>
</form>
</body>
</html>

