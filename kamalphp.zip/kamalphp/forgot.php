<?php
$host="localhost";
$uname="root";
$pwd="";
$dbname="dblogin";
$conn=mysqli_connect("$host","$uname","$pwd","$dbname");
if(!$conn)
{
  die("connection failed" .mysqli_connect_error());
}
if(isset($_POST['submit']))
{ 
 
 $mail=$_POST['mail'];
 $qry="select * from login where mail='".$mail."' " or die(mysql_error());
$res=mysql_query($conn,$qry);
 $p=mysql_affected_rows();
 if($p!=0) 
 {
  $res1=mysql_fetch_array($res);
  $to=$res1['mail'];
  $subject='Remind password';
  $message='Your password : '.$res1['password']; 
  $headers='From:guruparthiban19@gmail.com';
  $m=mail($to,$subject,$message,$headers);
  if($m)
  {
    echo'Check your inbox in mail';
  }
  else
  {
   echo'mail is not send';
  }
 }
 else
 {
  echo'You entered mail id is not present';
 }
}
?>
<html>
<head>
</head>
<body>
<h1>Forgot Password<h1>
<form action='forgot' method='post'>
<table border="5" align='center'>
<tr><td>Email id:</td><td><input type='text' name='mail'/></td></tr>
<tr><td></td><td><input type='submit' name='submit' value='Submit'/></td></tr>
</table>
</form>
</body>
</html>
?>
