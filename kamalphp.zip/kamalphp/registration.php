<?php
session_start();
$host="localhost";
$uname="root";
$pwd="";
$dbname="dblogin";
$conn=mysqli_connect("$host","$uname","$pwd","$dbname");
if(!$conn)
{
	die("connection failed" .mysqli_connect_error());
}
if(isset($_POST["btnsub"]))
{
	$un=$_POST["txtusr"];
	$pwd=$_POST["txtpwd"];
	$fn=$_POST["txtfn"];
	$ln=$_POST["txtln"];
	$add=$_POST["txtadd"];
	$con=$_POST["txtcon"];
//$target_dir = "uploadimage/";
$pic = $_FILES["fileToUpload"]["name"];

	$gen=$_POST["txtgen"];
	$sql = "INSERT INTO tbusr (username,upawd,fname,lname,address,contact,pic,gender)
VALUES ('$un','$pwd','$fn','$ln','$add','$con','$pic','$gen')";

if (mysqli_query($conn, $sql)) 
{
    move_uploaded_file($_FILES['fileToUpload']['tmp_name'], uploadimage/$_FILES['fileToUpload']['name']);
    echo "New record created successfully";
    header("location:login.php");
} 
else
{
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}
?>
<html>
<head>
</head>
<body>
<form name="formlog" action="registration.php" method="post" enctype="multipart/form-data">
<table border="5">
<tr>
	<td>User name:</td>
	<td><input type="text" name="txtusr" /></td>
</tr>
<tr>
	<td>Password:</td>
	<td><input type="password" name="txtpwd" /></td>
</tr>
<tr>
	<td>First name:</td>
	<td><input type="text" name="txtfn" /></td>
</tr>
<tr>
	<td>Last name:</td>
	<td><input type="text" name="txtln" /></td>
</tr>
<tr>
	<td>Address:</td>
	<td><input type="text" name="txtadd" /></td>
</tr>
<tr>
	<td>Contact:</td>
	<td><input type="text" name="txtcon" /></td>
</tr>
<tr>
	<td>Picture :</td>
	<td><input type="file" name="fileToUpload" value="Upload image" /></td>
</tr>
<tr>
	<td>Gender:</td>
	<td><input type="radio" name="txtgen"  value="Male" />Male<br>
<input type="radio" name="txtgen"  value="Female" />Female
	</td>
</tr>
<tr>
	<td colspan="2">
		<input type="submit" name="btnsub" value="Submit" />
	</td>
</tr>
</table>
</form>
</body>
</html>


?>
