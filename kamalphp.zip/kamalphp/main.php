<?php 

require 'registration.php';
require 'login.php';
require 'profile.php';
require 'forget.php';

?>
