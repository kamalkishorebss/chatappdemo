app.service('loginservice', function($location){
	this.pass ="admin12345";
	this.check = function(psw){
		if(this.pass == psw){
			$location.path('/order');

		}
		else{
		      $location.path('/index');
		}
	}

});


 