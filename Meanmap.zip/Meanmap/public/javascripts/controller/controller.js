app.controller("logincontroller",function($scope,$location,$http,$localStorage, uiGmapGoogleMapApi,uiGmapIsReady)
    {


    	$scope.loginpage = function(){
		
		
		
	 	$http({
		  method: 'POST',
		  url: '/api/login',
		  data: {email:$scope.email, password:$scope.password},
		}).then(function successCallback(response) {
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else 
			{
		        $scope.dp = response.data;
				//$localStorage.pp = $scope.dp;
				
				//console.log($localStorage.pp)
				$location.path('/map');
		    
			}
		}, function errorCallback(response) {
		    console.log('error',response);
		});
	 }

//***signup

    $scope.signup = function() 
	{
    $http({
    method:"POST",
    url:'api/signup',
	data:{name:$scope.name, email:$scope.email,password:$scope.password,contact:$scope.contact,address:$scope.address}
     }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        //$localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/login');
      }
      console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
	
    //****google maps geolocation
  $scope.nginit = function(){

      function writeAddressName(latLng) {
        var geocoder = new google.maps.Geocoder();
        geocoder.geocode({
          "location": latLng
        },
        function(results, status) {
          if (status == google.maps.GeocoderStatus.OK)
            document.getElementById("address").innerHTML = results[0].formatted_address;
          else
            document.getElementById("error").innerHTML += "Unable to retrieve your address" + "<br />";
        });
      }

      function geolocationSuccess(position) {
        var userLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
        // Write the formatted address
        writeAddressName(userLatLng);

        var myOptions = {
          zoom : 16,
          center : userLatLng,
          mapTypeId : google.maps.MapTypeId.ROADMAP
        };
        // Draw the map
        var mapObject = new google.maps.Map(document.getElementById("map"), myOptions);
        // Place the marker
        new google.maps.Marker({
          map: mapObject,
          position: userLatLng
        });
        // Draw a circle around the user position to have an idea of the current localization accuracy
        var circle = new google.maps.Circle({
          center: userLatLng,
          radius: position.coords.accuracy,
          map: mapObject,
          fillColor: '#0000FF',
          fillOpacity: 0.5,
          strokeColor: '#0000FF',
          strokeOpacity: 1.0
        });
        mapObject.fitBounds(circle.getBounds());
      }

      function geolocationError(positionError) {
        document.getElementById("error").innerHTML += "Error: " + positionError.message + "<br />";
      }

      function geolocateUser() {
        // If the browser supports the Geolocation API
        if (navigator.geolocation)
        {
          var positionOptions = {
            enableHighAccuracy: true,
            timeout: 10 * 1000 // 10 seconds
          };
          navigator.geolocation.getCurrentPosition(geolocationSuccess, geolocationError, positionOptions);
        }
        else
          document.getElementById("error").innerHTML += "Your browser doesn't support the Geolocation API";
      }

      window.onload = geolocateUser;

  }

});



