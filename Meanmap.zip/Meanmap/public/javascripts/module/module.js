var app = angular.module("myApp",['ngRoute','ngStorage','uiGmapgoogle-maps']);
app.config(function($routeProvider){
 $routeProvider.
 when('/map',
 {
 controller:'logincontroller',
 templateUrl:'javascripts/view/home.html'
 }).
 when('/login',
 {
 controller:'logincontroller',
 templateUrl:'javascripts/view/login.html'
 }).
 when('/signup',
 {
 controller: 'logincontroller',
 templateUrl: 'javascripts/view/signup.html'
 }).
 otherwise({
	 redirectTo:'/login'
	 });
 //$locationProvider.html5Mode(true);
});