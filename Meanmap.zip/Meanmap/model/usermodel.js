var mongoose =require('mongoose');

var Schema = mongoose.Schema;

var userSchema = Schema({

	name:{type:String},
	email:{type:String, required:true},
    password:{type:String},
    contact:{type:Number},
    address:{type:String}
});

var User = mongoose.model('register',userSchema);

module.exports=User;