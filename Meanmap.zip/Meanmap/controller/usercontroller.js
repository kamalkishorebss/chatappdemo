//****************registion contoller**********************
var Usermodel = require('../model/usermodel');

module.exports.signup = function(req,res){
	var user    = new Usermodel();
     user.name  =req.body.name;
	 user.email =req.body.email;
	 user.password=req.body.password;
	 user.contact =req.body.contact;
	 user.address =req.body.address;
      
      console.log(req.body);

      user.save(function(err,data){
      	if(err){
      		res.send(err);
      	}
      	else{
      		console.log(data);
      		res.send(data);

      	}
      })
}

//****************login controller***********************
module.exports.login = function(req,res){

	var email =  req.body.email;
	var password = req.body.password;
	console.log(password);
	console.log(email);

	Usermodel.findOne({email:email},function(err,person){
		if(err){
			console.log(err);
		}
		else{
			if(person){
				if(person.password == password){
					res.send(person);
				    console.log(" successfully login");
				}
				else{

					console.log("invalid password");
				}
				
			}
			else{
                     console.log("invalid Email/password"); 

				}
		}
	});
} 