var app = angular.module('employeeRecords', [])
        .constant('API_URL', 'http://localhost/project1/public/api/v1/');