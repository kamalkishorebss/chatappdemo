<?php

namespace App;
use Moloquent;
//use Illuminate\Database\Eloquent\Model;

//class Employee extends Model
class Employee extends Moloquent
{
   protected $fillable = array('id', 'name', 'email','contact_number','position');
}